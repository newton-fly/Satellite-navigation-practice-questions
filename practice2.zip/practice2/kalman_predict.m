% 预测步骤
function [x_predict, P_predict] = kalman_predict(F, x_estimate, P_estimate, Q)
    % 预测状态
    x_predict = F * x_estimate;

    % 预测误差协方差
    P_predict = F * P_estimate * F' + Q;
end