% 更新步骤
function [x_update, P_update, K] = kalman_update(H, x_predict, P_predict, R, z)
    % 计算卡尔曼增益
    K = P_predict * H' / (H * P_predict * H' + R);

    % 更新状态估计
    x_update = x_predict + K * (z - H * x_predict);

    % 更新误差协方差
    P_update = (eye(size(x_predict, 1)) - K * H) * P_predict;
end