function [gps_week, gps_seconds] = convertToGPSTime(year, month, day, hour, minute, second)
    % 计算输入的 UTC 时间与 GPS 时间的差值（秒）
    utc_time = datetime(year, month, day, hour, minute, second);
    gps_start = datetime(1980, 1, 6, 0, 0, 0);
    time_difference = seconds(utc_time - gps_start);

    % 计算 GPS 周数和周内秒数
    gps_week = floor(time_difference / (7 * 24 * 60 * 60));
    gps_seconds = mod(time_difference, 7 * 24 * 60 * 60);
end