% 指定星历文件的路径
file_path = 'brdc3590.23n';

% 打开星历文件进行读取
fid = fopen(file_path, 'r');
if fid == -1
    error('无法打开文件');
end

% 初始化变量来存储文件头信息和数据
header_lines = cell(0);
data_params = []; % 存储卫星参数，每行代表一个参数含义

% 读取文件内容
while ~feof(fid)
    line = strtrim(fgetl(fid)); % 去除前置空格
    if startsWith(line, 'END OF HEADER')
        header_lines{end+1} = line; % 将 "END OF HEADER" 加入文件头信息
        break; % 当遇到 "END OF HEADER" 时停止读取文件头
    else
        header_lines{end+1} = line; % 将每一行文件头信息存储在header_lines中
    end
end

%%读取数据块
m=1;
while ~feof(fid)
    for block_line = 1:8
        if block_line==1
           line = fgetl(fid);
           if feof(fid)
            break; % 如果到达文件末尾，停止读取
           end 
           line=strtrim(line);
           pattern = '(\d+\.\d+D[+-]\d+)(-\d+\.\d+D[+-]\d+)';  
           replacement = '$1 $2';  
           line = regexprep(line, pattern, replacement);
           line = strrep(line,'.0-','.0 -')
           line = strrep(line,'D','e')
           split_line=strsplit(line);
           data = str2double(strsplit(line));
           for i=1:10
                data_params(i, m) =data(i);
           end
        else
           line = fgetl(fid);
           if feof(fid)
                break; % 如果到达文件末尾，停止读取
           end 
           line=strtrim(line);
           pattern = '(\d+\.\d+D[+-]\d+)(-\d+\.\d+D[+-]\d+)';  
           replacement = '$1 $2';  
           line = regexprep(line, pattern, replacement)
           pattern = '(-\d+\.\d+D[+-]\d+)(-\d+\.\d+D[+-]\d+)';  
           replacement = '$1 $2';  
           line = regexprep(line, pattern, replacement);
           line = strrep(line,'D','e')
           data = str2double(strsplit(line));
           for j=1:4
               n=(block_line-1)*4+j+6;
               data_params(n, m) = data(j);
           end
        end
    end
    m=m+1;
end
           
% 关闭文件
fclose(fid);

% 输出文件头信息
fprintf('文件头信息:\n');
for i = 1:numel(header_lines)
    disp(header_lines{i});
end

% 输出卫星参数
display(data_params);
%for i = 1:length(data_params)
    %fprintf('参数%d:\n', i);
    %disp(data_params{i});
%end

%计算卫星位置
GM=3.986005e14;
omegae=7.29211567e-5;
% 地球半径，单位为米
R = 6371000;
% 绘制地球
[x, y, z] = sphere(50);
x = R * x;
y = R * y;
z = R * z;
earth_surface = surf(x, y, z);
hold on;
for wx=1:32
    %计算卫星平均角速度
    sqrtA=data_params(18,wx);
    deltan=data_params(13,wx);
    n_t = sqrt(GM / (sqrtA^3)) + deltan;
    %平近点角
    a0=data_params(8,wx);
    a1=data_params(9,wx);
    a2=data_params(10,wx);
    year = data_params(2,wx);   % 年
    month = data_params(3,wx);  % 月
    day = data_params(4,wx);    % 日
    hour = data_params(5,wx);    % 时
    minute =data_params(6,wx);  % 分
    second = data_params(7,wx);  % 秒
    toe=data_params(19,wx);
    M0=data_params(14,wx);
    e=data_params(16,wx);
    omega=data_params(25,wx);
    [toc_gps_week, toc_gps] = convertToGPSTime(year, month, day, hour, minute, second);
    t_prime_gps=toc_gps;
    At = a0 + a1 * (t_prime_gps - toc_gps) + a2 * (t_prime_gps - toc_gps)^2;
    t = t_prime_gps - At;
    tk = t - toe;
    M = M0 + n_t * tk;
    %计算偏近点角
    E = M;
    for i = 1:4
        E = M + e * sin(E);
    end
    %真近点角
    nu = atan2(sqrt(1 - e^2) * sin(E), cos(E) - e);
    %计算升交距角
    u = omega + nu;
    %计算摄动改正项
    Cuc=data_params(15,wx);
    Cus=data_params(17,wx);
    Crs=data_params(12,wx);
    Crc=data_params(24,wx);
    Cis=data_params(22,wx);
    Cic=data_params(20,wx);
    i0=data_params(23,wx);
    IDOT=data_params(27,wx);
    OMEGA=data_params(21,wx);
    deltaomega=data_params(26,wx);
    % 计算升交距角的摄动改正项
    du = Cus * sin(2 * u) + Cuc * cos(2 * u);
    % 计算卫星矢径的摄动改正项
    dr = Crs * sin(2 * u) + Crc * cos(2 * u);
    % 计算轨道倾角的摄动改正项
    di = Cis * sin(2 * u) + Cic * cos(2 * u);
    % 摄动改正后的升交距角
    u_corrected = u + du;
    % 摄动改正后的卫星矢径
    a=sqrtA^2;
    r_corrected = a * (1 - e * cos(E)) + dr;
    % 摄动改正后的轨道倾角
    i_corrected = i0 + di+ IDOT*tk;
    %计算卫星在轨道面坐标系中的坐标
    x = r_corrected * cos(u_corrected);
    y = r_corrected * sin(u_corrected);
    %计算发射时刻升交点的经度
    L=OMEGA+deltaomega*tk-omegae*(tk+toe);
    %计算卫星在地固坐标系下的坐标
    Xs=x*cos(L)-y*cos(i_corrected)*sin(L);
    Ys=x*sin(L)-y*cos(i_corrected)*cos(L);
    Zs=y*sin(i_corrected);
    plot3(Xs, Ys, Zs, 'bo', 'MarkerSize', 10);
    text(Xs, Ys, Zs, num2str(wx));
    hold on;

end
title('Satellite Position in ECEF Coordinates');
xlabel('X');
ylabel('Y');
zlabel('Z');
grid on;
axis equal;