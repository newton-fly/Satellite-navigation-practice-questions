% 参数设定
info_rate = 50;          % 数据码信息速率，单位：bps
pseudo_len = 1023;       % C/A 码长度
pseudo_f = 1.023e6;
L1_carrier_freq = 1.57542e9; % L1载波频率，单位：Hz
doppler_freq = 10000;      % 多普勒频率，单位：Hz
pseudo_phase_offset = 200; % 伪码相位偏移
snr = -30;               % 信噪比，单位：dB
infolen=2;             %信息码长

% 初始化 C/A 码序列
ca_code = zeros(1, pseudo_len);

% 生成 C/A 码序列
ca_code = circshift(cacode(1,1), [0 pseudo_phase_offset]);

% 生成随机的信息比特（数据码）
info_bits = randi([0 1], 1, infolen); % 一个码元包括20个完整C/A码周期

% 对信息比特与C/A码进行异或操作（扩频）
spread_info_bits = zeros(1, pseudo_len * 20*infolen);
m=0;
for i = 1:infolen
    info=info_bits(i);
    for j=1:20
        for k=1:pseudo_len
            ca=ca_code(k);
            m=m+1;
            spread_info_bits(m)=xor(info,ca);
        end
    end
end
% 对扩频后的信号进行BPSK调制
modulated_signal = 2 * spread_info_bits - 1;

% 生成时间向量
t_pseudo = (0:length(modulated_signal) - 1)*(0.001/1023) ;

% 多普勒频移

% 生成载波信号
carrier_signal = cos(2 * pi *( L1_carrier_freq+doppler_freq) * t_pseudo );

% 将调制后的信号与载波相乘
signal_with_carrier = modulated_signal .* carrier_signal;

% 添加高斯白噪声
signal_with_noise = awgn(signal_with_carrier, snr, 'measured'); % 添加高斯白噪声

% 显示生成的信号
subplot(2,1,1)
plot(signal_with_carrier);
xlabel('时间');
ylabel('信号幅度');
title('生成的GPS信号');
subplot(2,1,2)
plot(signal_with_noise);
xlabel('时间');
ylabel('信号幅度');
title('生成的GPS信号有噪');

%捕获阶段

x=0;
for f=0:1000:20000
    doppler_freq1=f;
    x=x+1;
    y=0;
    for of=0:1023
        pseudo_phase_offset1=of;
        y=y+1;
        % 生成本地的 C/A 码
        lca_code =  circshift(cacode(1,1), [0 pseudo_phase_offset1]);
        m=0;
        local_ca_code = zeros(1, pseudo_len * 20*infolen);
        for i = 1:infolen
            for j=1:20
                for k=1:pseudo_len
                    ca=lca_code(k);
                    m=m+1;
                    local_ca_code(m)=ca;
                end
            end
        end

        % 将本地的 C/A 码与接收到的信号相乘（这是预处理的一部分）
        signal_with_noise1=junzhi(signal_with_noise);
        processed_signal = signal_with_noise .* local_ca_code;

        % 显示处理后的信号
        %figure 
        %subplot(2,2,1);
        %plot(processed_signal);
        %xlabel('时间');
        %ylabel('信号幅度');
        %title('处理后的信号（本地C/A码与接收信号相乘）');

        [carrier_cos, carrier_sin] = generate_local_carrier_signal(length(signal_with_noise), L1_carrier_freq, doppler_freq1);

        % 将本地载波信号的余弦和正弦分量与处理后的信号相乘
        processed_signal_cos = processed_signal .* carrier_cos;
        processed_signal_sin = processed_signal .* carrier_sin;

        % 显示处理后的信号（余弦分量）
        %subplot(2,2,2)
        %plot(processed_signal_cos);
        %xlabel('时间');
        %ylabel('信号幅度');
        %title('处理后的信号（余弦分量）');

        % 显示处理后的信号（正弦分量）
        %subplot(2,2,3)
        %plot(processed_signal_sin);
        %xlabel('时间');
        %ylabel('信号幅度');
        %title('处理后的信号（正弦分量）');

        % 计算时间步长
        time_step = 0.001/1023; % 采样间隔

        % 选择2ms的时间间隔
        time_interval = 0.02; % 5ms
        num_samples = ceil(time_interval / time_step); % 计算在这段时间内的采样点数

        % 提取2ms时间内的信号
        signal_cos_1ms = processed_signal_cos(1:num_samples);
        signal_sin_1ms = processed_signal_sin(1:num_samples);

        % 计算余弦分量在1ms内的积分值I
        I = sum(signal_cos_1ms) ;
        % 计算正弦分量在1ms内的积分值Q
        Q = sum(signal_sin_1ms);
        % 计算I和Q的平方和
        sum_of_squares = I^2 + Q^2;
        p(x,y)=sum_of_squares;
        % 显示计算得到的I和Q
        %fprintf('在1ms内的积分值I为: %f\n', I);
        %fprintf('在1ms内的积分值Q为: %f\n', Q);
        %fprintf('I和Q的平方和为: %f\n', sum_of_squares);
    end
end
figure 
mesh(p)
title('捕获结果');
figure
subplot(1,2,1)
plot(0:1000:20000,p);
xlabel('多普勒频移');
ylabel('I^2 + Q^2');
title('多普勒频移捕获结果');
subplot(1,2,2)
plot(0:1023,p);
xlabel('C/A码相位');
ylabel('I^2 + Q^2');
title('C/A码相位捕获结果');
[x,y]=find(p==max(max(p)))

