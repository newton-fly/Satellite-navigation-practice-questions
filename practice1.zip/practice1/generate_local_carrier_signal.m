function [carrier_cos, carrier_sin] = generate_local_carrier_signal(signal_length, L1_carrier_freq, doppler_freq)
    t = (0:signal_length - 1)*(0.001/1023); % 生成时间向量

    % 生成本地的载波信号的余弦和正弦分量，考虑L1频率和多普勒频移
    carrier_cos = cos(2 * pi * (L1_carrier_freq + doppler_freq) * t); % 生成本地载波信号的余弦分量
    carrier_sin = sin(2 * pi * (L1_carrier_freq + doppler_freq) * t); % 生成本地载波信号的正弦分量
end